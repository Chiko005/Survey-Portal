<?php
session_start();
require 'dbConnect.php';

if (!isset($_SESSION['user_id'])) {
  header("Location: index.php");
  exit;
}

if (!isset($_GET['id'])) {
  header("Location: notifications.php");
  exit;
}

$survey_id = $_GET['id'];
$user_id = $_SESSION['user_id'];

// Verify ownership
$stmt = $pdo->prepare("SELECT title FROM surveys WHERE id = ? AND user_id = ?");
$stmt->execute([$survey_id, $user_id]);
$survey = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$survey) {
  echo "Survey not found or access denied.";
  exit;
}

// Get responses
$responseStmt = $pdo->prepare("SELECT * FROM responses WHERE survey_id = ? ORDER BY id DESC");
$responseStmt->execute([$survey_id]);
$responses = $responseStmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Survey Responses</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script>
    function toggleDarkMode() {
      document.documentElement.classList.toggle('dark');
      localStorage.setItem('theme', document.documentElement.classList.contains('dark') ? 'dark' : 'light');
    }

    window.onload = () => {
      if (localStorage.getItem('theme') === 'dark') {
        document.documentElement.classList.add('dark');
      }
    };
  </script>
</head>
<body class="bg-gray-100 dark:bg-gray-900 text-gray-900 dark:text-white min-h-screen flex flex-col">

  <!-- Top bar -->
  <div class="w-full p-4 bg-white dark:bg-gray-800 shadow-md flex justify-between items-center">
    <h1 class="text-2xl font-bold">Responses to: <?= htmlspecialchars($survey['title']) ?></h1>
    <div class="flex items-center space-x-4">
      <a href="notifications.php" class="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-md">Back</a>
      <button onclick="toggleDarkMode()" class="text-gray-800 dark:text-gray-200">🌗</button>
      <a href="logout.php" class="text-red-600 dark:text-red-400 font-semibold">Logout</a>
    </div>
  </div>

  <!-- Main content -->
  <main class="flex-grow px-6 py-10">
    <h2 class="text-xl font-bold mb-6">All Responses</h2>

    <?php if (empty($responses)): ?>
      <p class="text-gray-500">No responses yet.</p>
    <?php else: ?>
      <div class="space-y-4">
        <?php foreach ($responses as $res): ?>
          <div class="bg-white dark:bg-gray-800 p-4 rounded-md shadow">
            <p class="text-sm text-gray-700 dark:text-gray-300">Response ID: <?= $res['id'] ?> | Submitted on <?= $res['created_at'] ?></p>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </main>

  <!-- Footer -->
  <footer class="w-full bg-gray-200 dark:bg-gray-800 text-center py-4">
    <p class="text-gray-700 dark:text-gray-300">Contact us at <a href="mailto:support@surveyapp.com" class="underline">support@surveyapp.com</a></p>
    <div class="flex justify-center mt-2 space-x-4 text-2xl">
      <a href="https://instagram.com" target="_blank" class="text-pink-500 hover:scale-110 transition"><i class="fab fa-instagram"></i></a>
      <a href="https://linkedin.com" target="_blank" class="text-blue-700 hover:scale-110 transition"><i class="fab fa-linkedin"></i></a>
    </div>
  </footer>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/js/all.min.js"></script>
</body>
</html>
