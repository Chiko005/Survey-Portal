<?php
session_start();
require 'dbConnect.php';

if (!isset($_SESSION['user_id'])) {
  header("Location: index.php");
  exit;
}

$user_id = $_SESSION['user_id'];

// Get user's surveys
$stmt = $pdo->prepare("SELECT s.id, s.title, COUNT(r.id) as response_count
                       FROM surveys s
                       LEFT JOIN responses r ON s.id = r.survey_id
                       WHERE s.user_id = ?
                       GROUP BY s.id, s.title
                       ORDER BY s.id DESC");
$stmt->execute([$user_id]);
$surveys = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Notifications</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script>
    function toggleDarkMode() {
      document.documentElement.classList.toggle('dark');
      localStorage.setItem('theme', document.documentElement.classList.contains('dark') ? 'dark' : 'light');
    }

    window.onload = () => {
      if (localStorage.getItem('theme') === 'dark') {
        document.documentElement.classList.add('dark');
      }
    };
  </script>
</head>
<body class="bg-gray-100 dark:bg-gray-900 text-gray-900 dark:text-white min-h-screen flex flex-col">

  <!-- Top bar -->
  <div class="w-full p-4 bg-white dark:bg-gray-800 shadow-md flex justify-between items-center">
    <h1 class="text-2xl font-bold">Your Notifications</h1>
    <div class="flex items-center space-x-4">
      <a href="home.php" class="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-md">Home</a>
      <button onclick="toggleDarkMode()" class="text-gray-800 dark:text-gray-200">🌗</button>
      <a href="logout.php" class="text-red-600 dark:text-red-400 font-semibold">Logout</a>
    </div>
  </div>

  <!-- Main content -->
  <main class="flex-grow px-6 py-10">
    <h2 class="text-xl font-bold mb-6">Replies to Your Surveys</h2>

    <?php if (empty($surveys)): ?>
      <p>You haven’t created any surveys yet.</p>
    <?php else: ?>
      <div class="space-y-4">
        <?php foreach ($surveys as $survey): ?>
          <div class="p-4 bg-white dark:bg-gray-800 rounded-lg shadow-md">
            <h3 class="text-lg font-semibold"><?= htmlspecialchars($survey['title']) ?></h3>
            <p class="text-sm text-gray-500 dark:text-gray-400">Responses received: <?= $survey['response_count'] ?></p>
<a href="survey_responses.php?id=<?= $survey['id'] ?>" class="inline-block mt-2 text-indigo-600 hover:underline text-sm">View Details</a>

          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </main>

  <!-- Footer -->
  <footer class="w-full bg-gray-200 dark:bg-gray-800 text-center py-4">
    <p class="text-gray-700 dark:text-gray-300">Contact us at <a href="mailto:support@surveyapp.com" class="underline">support@surveyapp.com</a></p>
    <div class="flex justify-center mt-2 space-x-4 text-2xl">
      <a href="https://instagram.com" target="_blank" class="text-pink-500 hover:scale-110 transition"><i class="fab fa-instagram"></i></a>
      <a href="https://linkedin.com" target="_blank" class="text-blue-700 hover:scale-110 transition"><i class="fab fa-linkedin"></i></a>
    </div>
  </footer>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/js/all.min.js"></script>
</body>
</html>
